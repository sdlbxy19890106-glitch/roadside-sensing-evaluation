"""Reproduce manuscript tables and summary plots from the public aggregate data."""
import argparse
import csv
import math
from collections import defaultdict
from pathlib import Path

DATA = Path(__file__).resolve().parents[1] / "data"
SITES = ("intersection", "highway")
SHIFTS = ("none", "forward", "left", "right")


def read_rows(filename):
    with (DATA / filename).open(encoding="utf-8", newline="") as stream:
        return list(csv.DictReader(stream))


def write_table(out, filename, fields, rows):
    with (out / filename).open("w", encoding="utf-8", newline="") as stream:
        writer = csv.writer(stream, lineterminator="\n")
        writer.writerow(fields.split())
        writer.writerows(rows)


def pooled_rmse(means, weights):
    return math.sqrt(sum(m * n for m, n in zip(means, weights)) / sum(weights))


def counts_to_pct(tp, fp, fn):
    return 100 * tp / (tp + fp), 100 * tp / (tp + fn)


def position_tables(out, position):
    held = {(r["site"], int(r["fold"])): int(r["held_vehicles"]) for r in position if r["shift"] == "none"}
    totals = {site: sum(n for (s, _), n in held.items() if s == site) for site in SITES}
    sample = []
    for fold in range(1, 6):
        values = []
        for site in SITES:
            n = held[site, fold]
            values.extend((n, totals[site] - n))
        sample.append([fold, *values])
    write_table(out, "table_1.csv", "fold intersection_held intersection_available highway_held highway_available", sample)
    summary = []
    for site in SITES:
        for shift in SHIFTS:
            rows = [r for r in position if r["site"] == site and r["shift"] == shift]
            weights = [int(r["held_vehicles"]) for r in rows]
            result = [pooled_rmse([float(r[col]) for r in rows], weights) for col in ("fixed_mse_m2", "refitted_mse_m2")]
            summary.append((site, shift, *result))
    write_table(out, "table_2.csv", "site shift fixed_rmse_m refitted_rmse_m",
                [(site, shift, f"{fixed:.3f}", f"{refit:.3f}") for site, shift, fixed, refit in summary])
    return summary


def timing_tables(out, calibration, controls, curves):
    weights = [int(r["held_vehicles"]) for r in calibration]
    single = pooled_rmse([float(r["mean_single_mse_m2"]) for r in calibration], weights)
    joint = pooled_rmse([float(r["joint_rmse_m"])**2 for r in calibration], weights)
    write_table(out, "calibration_summary.csv", "site held_vehicles single_rmse_m joint_rmse_m",
                [("intersection", sum(weights), f"{single:.3f}", f"{joint:.3f}")])
    sensitivity = []
    for r in calibration:
        curve = [q for q in curves if q["fold"] == r["fold"]]
        best = min(curve, key=lambda q: float(q["held_rmse_m"]))
        sensitivity.append((r["fold"], best["offset_ms"], f'{float(best["held_rmse_m"]):.3f}',
                            r["joint_offset_ms"], f'{float(r["max_omit_one_change_m"]):.3f}'))
    write_table(out, "calibration_diagnostics.csv", "fold lowest_error_offset_in_window_ms lowest_rmse_m joint_offset_ms max_omit_one_change_m", sensitivity)
    delays = []
    for site in SITES:
        for shift in ("none","forward"):
            rows = [r for r in controls if r["site"] == site and r["shift"] == shift]
            changes = [int(r["refitted_offset_ms"]) - int(r["original_offset_ms"]) for r in rows]
            delays.append((site, shift, rows[0]["added_delay_ms"], min(changes), max(changes)))
    write_table(out, "timing_controls.csv", "site shift added_delay_ms offset_change_min_ms offset_change_max_ms", delays)


def threshold_tables(out, counts, replays):
    grouped = defaultdict(lambda: [0, 0, 0])
    for r in counts:
        values = grouped[int(r["threshold_m"])]
        for i, col in enumerate(("tp", "fp", "fn")):
            values[i] += int(r[col])
    threshold_rows = []
    for d, (tp, fp, fn) in sorted(grouped.items()):
        p, q = counts_to_pct(tp, fp, fn)
        threshold_rows.append((d, tp, fp, fn, p, q))
    write_table(out, "table_3.csv", "threshold_m tp fp fn precision_pct recall_pct",
                [(d, tp, fp, fn, f"{p:.2f}", f"{q:.2f}") for d, tp, fp, fn, p, q in threshold_rows])
    by_class = []
    for r in counts:
        p, q = counts_to_pct(*(int(r[key]) for key in ("tp", "fp", "fn")))
        by_class.append((r["threshold_m"], r["class"], f"{p:.2f}", f"{q:.2f}"))
    write_table(out, "detection_by_class.csv", "threshold_m class precision_pct recall_pct", by_class)
    replay_rows = []
    for r in replays:
        p5, q5 = counts_to_pct(*(int(r[f"{k}_5m"]) for k in ("tp", "fp", "fn")))
        p10, q10 = counts_to_pct(*(int(r[f"{k}_10m"]) for k in ("tp", "fp", "fn")))
        net = int(r["tp_10m"]) - int(r["tp_5m"])
        assert net == int(r["gained"]) - int(r["lost"])
        replay_rows.append((r["offset_ms"], r["paired_lists"], f"{p5:.2f}", f"{q5:.2f}", f"{p10:.2f}", f"{q10:.2f}", net,
                            r["changed_lists"], r["unchanged_count_among_changed"], r["gained"], r["lost"], r["reassigned"]))
    write_table(out, "threshold_replay_summary.csv",
                "offset_ms paired_lists precision_5m_pct recall_5m_pct precision_10m_pct recall_10m_pct net_matches changed_lists unchanged_count_among_changed gained lost reassigned", replay_rows)
    return threshold_rows


def make_plots(out, positions, thresholds, calibration, curves):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    blue, orange = "#225885", "#ad5216"
    fig, axes = plt.subplots(1, 2, figsize=(9, 3.6), sharey=True, layout="constrained")
    for ax, site in zip(axes, SITES):
        rows = [r for r in positions if r[0] == site]
        x = list(range(len(rows)))
        for delta, field, name, color in [(-.18, 2, "Pre-shift offset", blue), (.18, 3, "Re-estimated offset", orange)]:
            ax.bar([v + delta for v in x], [r[field] for r in rows], .36, label=name, color=color)
        ax.set(xticks=x, xticklabels=["Original", "Forward", "Left", "Right"], title=site.title(), ylabel="Position RMSE (m)")
    axes[0].legend(frameon=False)
    fig.savefig(out / "position_shifts.png", dpi=190)
    plt.close(fig)

    fig, ax = plt.subplots(figsize=(5.6, 3.7), layout="constrained")
    for i, name, color, marker in [(4, "Precision", blue, "o"), (5, "Recall", orange, "s")]:
        ax.plot([r[0] for r in thresholds], [r[i] for r in thresholds], marker=marker, label=name, color=color)
    ax.set(xlabel="Distance threshold (m)", ylabel="Percentage of observations (%)",
           ylim=(0, 100), xticks=[r[0] for r in thresholds])
    ax.legend(frameon=False)
    fig.savefig(out / "detection_thresholds.png", dpi=190)
    plt.close(fig)

    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(9, 4), layout="constrained")
    for r in calibration:
        fold = int(r["fold"])
        curve = sorted((q for q in curves if int(q["fold"]) == fold), key=lambda q: int(q["offset_ms"]))
        x = [int(q["offset_ms"]) for q in curve]
        y = [float(q["held_rmse_m"]) for q in curve]
        line, = ax1.plot(x, y, label=f"Fold {fold}")
        color = line.get_color()
        ax1.plot(int(r["joint_offset_ms"]), float(r["joint_rmse_m"]), "s", color=color)
        ax2.plot([float(r["single_min_rmse_m"]), float(r["single_max_rmse_m"])], [fold,fold], color=color)
        ax2.plot(float(r["joint_rmse_m"]), fold, "s", color=color)
    ax1.set(xlabel="Time offset (ms)", ylabel="Held-out position RMSE (m)")
    ax1.legend(frameon=False, fontsize="small")
    ax2.set(xlabel="Held-out position RMSE (m)", ylabel="Fold", yticks=range(1,6),
            title="Line: single-vehicle range\nSquare: multi-vehicle result")
    ax2.invert_yaxis()
    fig.savefig(out / "calibration_sensitivity.png", dpi=190)
    plt.close(fig)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True, help="Directory for derived CSV tables and optional plots")
    parser.add_argument("--plots", action="store_true", help="Also draw three PNG figures (requires matplotlib >= 3.6)")
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    calibration = read_rows("calibration_folds.csv")
    curves = read_rows("offset_response.csv")
    positions = position_tables(args.output, read_rows("position_folds.csv"))
    timing_tables(args.output, calibration, read_rows("time_controls.csv"), curves)
    thresholds = threshold_tables(args.output, read_rows("detection_counts.csv"), read_rows("threshold_replays.csv"))
    if args.plots:
        make_plots(args.output, positions, thresholds, calibration, curves)


if __name__ == "__main__":
    main()

