# Numerical data dictionary

These UTF-8 CSV files contain group-level results for the urban intersection and the public highway sample. They support independent calculation of the paper's tables and summary plots. The unit of analysis differs by experiment. A position error belongs to a held-out vehicle, whereas a detection count belongs to an object observation in a pair of lists. Repeated observations of the same road user can contribute more than once to the detection counts.

| File | One row represents | Fields and units |
| --- | --- | --- |
| `position_folds.csv` | One site, held-out fold and shift direction | `held_vehicles` is the number of trajectory pairs in that fold. Each MSE field is the mean of the vehicle-level mean squared two-dimensional position errors (m²). `fixed_mse_m2` retains the offset estimated before the shift. `refitted_mse_m2` uses the offset estimated after the shift. The last two fields give these offsets in milliseconds. |
| `calibration_folds.csv` | One held-out fold at the intersection | `available_vehicles` counts the vehicles in the other four folds. The single-vehicle fields give the minimum and maximum estimated offsets (ms), the minimum and maximum held-out RMSE (m), and the mean held-out MSE over the available single-vehicle choices (m²). The joint fields give the offset and held-out RMSE when all available vehicles supplied the estimate. `max_omit_one_change_m` is the largest absolute change in that RMSE after removing one available vehicle. |
| `offset_response.csv` | One intersection fold evaluated at one offset | `held_rmse_m` is the held-out RMSE at `offset_ms`. The released values span 580–681 ms at 1 ms intervals. They are evaluations of a fixed group. Choosing the lowest held-out error is a retrospective diagnostic. |
| `time_controls.csv` | One site and fold in the 120 ms delay control | `shift` indicates a delay alone (`none`) or a delay plus a 1 m forward shift. The change in estimated offset (ms) equals `refitted_offset_ms` minus `original_offset_ms`. |
| `detection_counts.csv` | One target class at one distance threshold at the intersection | The time offset is 681 ms throughout. `tp` counts matches, `fp` unmatched roadside reports and `fn` unmatched aerial observations. Each count is summed over the paired lists. |
| `threshold_replays.csv` | One offset compared at distance thresholds of 5 and 10 m at the intersection | `paired_lists` counts the list pairs used at both distances within that row. The six `tp`, `fp` and `fn` fields give totals across all three classes, separately at 5 and 10 m. The remaining columns describe changes in assignments between those thresholds. |

## Interpreting the columns

- The fold number ranges from 1 to 5 separately at each site. Vehicles are counted once as held out. In the position experiments, `none` denotes the original reports. The `forward`, `left` and `right` conditions impose a 1 m shift relative to the direction of travel. Offsets at the highway site are relative to the timing supplied with that dataset.
- To pool position errors across folds, weight each fold MSE by its number of held-out vehicles, take the mean and then take the square root. To pool single-vehicle choices, first average the squared errors across choices within a fold (already supplied in `mean_single_mse_m2`). These operations preserve equal weight per held-out vehicle.
- For detection results, sum the three classes before computing precision = TP / (TP + FP) and recall = TP / (TP + FN). The class `non_motorized_vehicle` is the study's non-motorized vehicle category.
- In the threshold replays, `changed_lists` counts list pairs in which at least one assignment changed. `unchanged_count_among_changed` counts the subset where the number of matches stayed constant. `gained` and `lost` count aerial observations that became matched or unmatched, respectively. `reassigned` counts aerial observations that remained matched but received a different roadside report. The net gain in matches equals `gained` minus `lost`.
- The threshold comparison uses the same paired lists within each offset. Different offsets can select different pairs of observation times. The changes from 5 to 10 m are therefore interpreted separately for each row.

## Running the analysis

From the package root, use `python analysis/reproduce.py --output results` to write Tables 1–3 and the calibration, timing-control, class-specific and threshold-replay summaries. Add `--plots` for three PNG figures showing the position shifts, calibration sensitivity and pooled detection metrics. Table generation uses the Python standard library. Plots require Matplotlib 3.6 or later.

The package starts at the level of aggregated experimental outputs. Creating aerial trajectories from images, assigning observations to objects and replaying individual traffic events require data and software outside this numerical release.

